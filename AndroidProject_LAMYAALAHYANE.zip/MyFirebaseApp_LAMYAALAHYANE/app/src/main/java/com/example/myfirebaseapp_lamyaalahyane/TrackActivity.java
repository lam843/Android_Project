package com.example.myfirebaseapp_lamyaalahyane;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class TrackActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float[] gravity = new float[3];
    private float[] linearAcceleration = new float[3];
    private TextView statusTextView;
    private TextView activityStandingConfidenceTextView;
    private TextView activitySittingConfidenceTextView;
    private TextView activityWalkingConfidenceTextView;
    private TextView activityJumpingConfidenceTextView;
    private TextView activityRunningConfidenceTextView;

    private int[] confidenceValues = new int[5]; // Increased array size for running activity
    private int windowSize = 10;
    private int[] activityWindow = new int[windowSize];
    private int windowIndex = 0;
    private Button btn_map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_track);


        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        statusTextView = findViewById(R.id.statusTextView);
        activityStandingConfidenceTextView = findViewById(R.id.activityStandingConfidenceTextView);
        activitySittingConfidenceTextView = findViewById(R.id.activitySittingConfidenceTextView);
        activityWalkingConfidenceTextView = findViewById(R.id.activityWalkingConfidenceTextView);
        activityJumpingConfidenceTextView = findViewById(R.id.activityJumpingConfidenceTextView);
        activityRunningConfidenceTextView = findViewById(R.id.activityRunningConfidenceTextView); // Added TextView for running
        /*btn_map = findViewById(R.id.btn_mapactivity);
        btn_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });*/
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            final float alpha = 0.8f;
            gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
            gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
            gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

            linearAcceleration[0] = event.values[0] - gravity[0];
            linearAcceleration[1] = event.values[1] - gravity[1];
            linearAcceleration[2] = event.values[2] - gravity[2];

            // Determine the activity based on the accelerometer data
            int activity = getActivity(linearAcceleration);

            // Update the activity window
            activityWindow[windowIndex] = activity;
            windowIndex = (windowIndex + 1) % windowSize;

            // Smooth the confidence values using the activity window
            int[] smoothedConfidence = smoothConfidence(activityWindow);

            // Update the status text view
            String status;
            switch (activity) {
                case 0:
                    status = "Sitting";
                    break;
                case 1:
                    status = "Standing";
                    break;
                case 2:
                    status = "Walking";
                    break;
                case 3:
                    status = "Jumping";
                    break;
                case 4:
                    status = "Running"; // Added case for Running
                    break;
                default:
                    status = "Unknown";
            }
            statusTextView.setText("You are " + status + "...");

            // Update the confidence values in the table
            activityStandingConfidenceTextView.setText(smoothedConfidence[1] + "%");
            activitySittingConfidenceTextView.setText(smoothedConfidence[0] + "%");
            activityWalkingConfidenceTextView.setText(smoothedConfidence[2] + "%");
            activityJumpingConfidenceTextView.setText(smoothedConfidence[3] + "%");
            activityRunningConfidenceTextView.setText(smoothedConfidence[4] + "%"); // Added TextView for running
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }

    private int getActivity(float[] acceleration) {
        // Determine the activity based on the accelerometer data
        int activity;
        float magnitude = calculateMagnitude(acceleration);

        if (magnitude < 2.0f) {
            activity = 0; // Standing
        } else if (magnitude < 5.0f) {
            activity = 1; // Sitting
        } else if (magnitude < 8.0f) {
            activity = 2; // Walking
        } else if (magnitude < 12.0f) {
            activity = 3; // Jumping
        } else {
            activity = 4; // Running
        }
        return activity;
    }

    private float calculateMagnitude(float[] acceleration) {
        float sumOfSquares = 0.0f;
        for (float value : acceleration) {
            sumOfSquares += value * value;
        }
        return (float) Math.sqrt(sumOfSquares);
    }

    private int[] smoothConfidence(int[] activityWindow) {
        int[] smoothedConfidence = new int[5]; // Increased array size for running activity
        for (int activity : activityWindow) {
            smoothedConfidence[activity]++;
        }
        for (int i = 0; i < smoothedConfidence.length; i++) {
            smoothedConfidence[i] = (smoothedConfidence[i] * 100) / windowSize;
        }
        return smoothedConfidence;
    }

}
