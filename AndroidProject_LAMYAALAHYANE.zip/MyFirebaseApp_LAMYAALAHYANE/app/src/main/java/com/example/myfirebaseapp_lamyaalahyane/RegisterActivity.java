package com.example.myfirebaseapp_lamyaalahyane;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegisterActivity extends AppCompatActivity {

    private EditText name, email, major, mobile, pwd, confirmpwd;
    private ProgressBar pbar;
    private RadioGroup rg;
    private RadioButton buttselected;
    private static final String TAG = "RegisterActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_register);
        Toast.makeText(RegisterActivity.this, "You can register now ", Toast.LENGTH_LONG).show();

        name = findViewById(R.id.edittext_register_full_name);
        email = findViewById(R.id.edittext_register_email);
        major = findViewById(R.id.edittext_register_major);
        pwd = findViewById(R.id.edittext_register_password);
        mobile = findViewById(R.id.edittext_register_mobile);
        confirmpwd = findViewById(R.id.edittext_register_repeatpassword);
        rg = findViewById(R.id.radio_group_register_gender);
        pbar = findViewById(R.id.progressBar);
        rg.clearCheck();

        Button register = findViewById(R.id.button_register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedGenderId = rg.getCheckedRadioButtonId();
                buttselected = findViewById(selectedGenderId);

                String textFullname = name.getText().toString();
                String textemail = email.getText().toString();
                String textmajor = major.getText().toString();
                String textmobile = mobile.getText().toString();
                String textpwd = pwd.getText().toString();
                String textconfirmpwd = confirmpwd.getText().toString();
                String textGender;
                if (TextUtils.isEmpty(textFullname)) {
                    Toast.makeText(RegisterActivity.this, "fill the name ", Toast.LENGTH_LONG).show();
                    name.setError("must fill name");
                    name.requestFocus();
                } else if (TextUtils.isEmpty(textemail)) {
                    Toast.makeText(RegisterActivity.this, "fill the email ", Toast.LENGTH_LONG).show();
                    email.setError("must fill email");
                    email.requestFocus();
                } else if (!Patterns.EMAIL_ADDRESS.matcher(textemail).matches()) {
                    Toast.makeText(RegisterActivity.this, "fill  email ", Toast.LENGTH_LONG).show();
                    email.setError("must fill valide email");
                    email.requestFocus();

                } else if (TextUtils.isEmpty(textmajor)) {
                    Toast.makeText(RegisterActivity.this, "fill  major ", Toast.LENGTH_LONG).show();
                    major.setError("must fill  major");
                    major.requestFocus();

                } else if (rg.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(RegisterActivity.this, "Gender.. ", Toast.LENGTH_LONG).show();
                    buttselected.setError("must chose gender");
                    buttselected.requestFocus();

                } else if (TextUtils.isEmpty(textmobile)) {
                    Toast.makeText(RegisterActivity.this, "fill  mobile ", Toast.LENGTH_LONG).show();
                    mobile.setError("must fill  mobile");
                    mobile.requestFocus();
                } else if (TextUtils.isEmpty(textpwd)) {
                    Toast.makeText(RegisterActivity.this, "fill  password ", Toast.LENGTH_LONG).show();
                    pwd.setError("must fill  password");
                    pwd.requestFocus();
                } else if (textpwd.length() < 8) {
                    Toast.makeText(RegisterActivity.this, "password should be at least 8 characters", Toast.LENGTH_LONG).show();
                    pwd.setError("weak password");
                    pwd.requestFocus();
                } else if (TextUtils.isEmpty(textconfirmpwd)) {
                    Toast.makeText(RegisterActivity.this, "fill  password ", Toast.LENGTH_LONG).show();
                    confirmpwd.setError("must fill  password");
                    confirmpwd.requestFocus();
                } else if (!textpwd.equals(textconfirmpwd)) {
                    Toast.makeText(RegisterActivity.this, "passwords should match", Toast.LENGTH_LONG).show();
                    confirmpwd.setError("passwords do not match");
                    confirmpwd.requestFocus();
                    pwd.getText().clear();
                    confirmpwd.getText().clear();
                } else {
                    textGender = buttselected.getText().toString();
                    pbar.setVisibility(View.VISIBLE);
                    registerUser(textFullname, textemail, textmajor, textGender, textmobile, textpwd);
                }
            }
        });
    }

    private void registerUser(String textFullname, String textemail, String textmajor, String textGender, String textmobile, String textpwd) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(textemail, textpwd).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    FirebaseUser firebaseUser = auth.getCurrentUser();
                    ReadWriteUserDetails writeUserDetails = new ReadWriteUserDetails(textFullname, textemail,textpwd, textmajor, textGender, textmobile);

                    DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Registered Users");

                    referenceProfile.child(firebaseUser.getUid()).setValue(writeUserDetails).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                firebaseUser.sendEmailVerification();
                                Toast.makeText(RegisterActivity.this, "User Registered Successfully. Please verify your email", Toast.LENGTH_LONG).show();
                              Intent intent=new Intent(RegisterActivity.this,ProfileActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_LONG).show();
                            }
                            pbar.setVisibility(View.GONE);
                        }
                    });
                } else {
                    try {
                        throw task.getException();
                    } catch (FirebaseAuthWeakPasswordException e) {
                        pwd.setError("Your password is weak. Please try again.");
                        pwd.requestFocus();
                    } catch (FirebaseAuthInvalidCredentialsException e) {
                        pwd.setError("Invalid email. Please try again.");
                        pwd.requestFocus();
                    } catch (FirebaseAuthUserCollisionException e) {
                        pwd.setError("User already exists. Please try again.");
                        pwd.requestFocus();
                    } catch (Exception e) {
                        Log.e(TAG, e.getMessage());
                        Toast.makeText(RegisterActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                    pbar.setVisibility(View.GONE);
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Registered Users");
        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    ReadWriteUserDetails userDetails = userSnapshot.getValue(ReadWriteUserDetails.class);
                    Log.d(TAG, "User Full Name: " + userDetails.getTextFullname());
                    Log.d(TAG, "User Email: " + userDetails.getTextemail());
                    Log.d(TAG, "User Major: " + userDetails.getTextmajor());
                    Log.d(TAG, "User Gender: " + userDetails.getTextGender());
                    Log.d(TAG, "User Mobile: " + userDetails.getTextmobile());
                    Log.d(TAG, "============================");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error retrieving users: " + databaseError.getMessage());
            }
        });
    }
}
