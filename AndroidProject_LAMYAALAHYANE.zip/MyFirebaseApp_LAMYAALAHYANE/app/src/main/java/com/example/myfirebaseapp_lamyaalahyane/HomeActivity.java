package com.example.myfirebaseapp_lamyaalahyane;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private TextView welcomeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_home);

        welcomeText = findViewById(R.id.welcome_text);

        Button profileButton = findViewById(R.id.button_profile);
        Button trackButton = findViewById(R.id.button_track);
        Button mapButton = findViewById(R.id.button_map);
        Button logoutButton = findViewById(R.id.button_logout);

        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, ProfileActivity.class));
            }
        });

        trackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, TrackActivity.class));
            }
        });

        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, activityRecognition.class));
            }
        });
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivity(new Intent(HomeActivity.this, MapActivity.class));
                Toast.makeText(HomeActivity.this, "LogOut... ", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(HomeActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });


        animateWelcomeText();
    }

    private void animateWelcomeText() {
        final String sentence = "Welcome to Our App !";

        ObjectAnimator animator = ObjectAnimator.ofFloat(welcomeText, View.ALPHA, 1f, 0f);
        animator.setDuration(9000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.RESTART);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            int currentIndex = 0;

            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float progress = animation.getAnimatedFraction();
                int index = (int) (progress * sentence.length());
                if (index > currentIndex) {
                    welcomeText.setText(sentence.substring(0, index));
                    currentIndex = index;
                }
                if (index >= sentence.length()) {
                    currentIndex = 0;
                    animation.setCurrentFraction(0);  // Reset the animation to start from the beginning
                }
            }
        });

        animator.start();
    }



}

