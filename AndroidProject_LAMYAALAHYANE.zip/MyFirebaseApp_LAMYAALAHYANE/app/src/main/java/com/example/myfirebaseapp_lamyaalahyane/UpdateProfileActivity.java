package com.example.myfirebaseapp_lamyaalahyane;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UpdateProfileActivity extends AppCompatActivity {
    private EditText editTextUpdatename, editTextUpdateemail, editTextUpdatemajor, editTextUpdatemobile, editTextUpdatepwd;
    private RadioGroup rgupdateGender;
    private String textFullName, textMajor, textGender, textMobile, textPwd, textEmail;
    private RadioButton rgButtonUpdateSelected;
    private FirebaseAuth authProfile;
    private DatabaseReference referenceProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_update_profile);

        getSupportActionBar().setTitle("Update Profile");
        editTextUpdatename = findViewById(R.id.EditText_show_full_name);
        editTextUpdateemail = findViewById(R.id.EditText_show_email);
        editTextUpdatemajor = findViewById(R.id.EditText_show_major);
        editTextUpdatemobile = findViewById(R.id.EditText_show_mobile);
        editTextUpdatepwd = findViewById(R.id.EditText_show_pwd);

        rgupdateGender = findViewById(R.id.radio_group_gender);
        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();
        referenceProfile = FirebaseDatabase.getInstance().getReference("Registered Users");

        showProfile(firebaseUser);

        Button btnupdate_pic = findViewById(R.id.update_pic);
        btnupdate_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UpdateProfileActivity.this, UploadProfilePicActivity.class);
                startActivity(intent);
                finish();
            }
        });

        Button btnupdate_profile = findViewById(R.id.update_profile);
        btnupdate_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateProfile(firebaseUser);
            }
        });
    }

    private void updateProfile(FirebaseUser firebaseUser) {
        int selectedGenderID = rgupdateGender.getCheckedRadioButtonId();
        rgButtonUpdateSelected = findViewById(selectedGenderID);
        textFullName = editTextUpdatename.getText().toString();
        textEmail = editTextUpdateemail.getText().toString();
        textMajor = editTextUpdatemajor.getText().toString();
        textMobile = editTextUpdatemobile.getText().toString();
        textPwd = editTextUpdatepwd.getText().toString();

        if (TextUtils.isEmpty(textFullName)) {
            Toast.makeText(UpdateProfileActivity.this, "Fill in the name", Toast.LENGTH_LONG).show();
            editTextUpdatename.setError("Must fill in the name");
            editTextUpdatename.requestFocus();
        } else if (TextUtils.isEmpty(textEmail)) {
            Toast.makeText(UpdateProfileActivity.this, "Fill in the email", Toast.LENGTH_LONG).show();
            editTextUpdateemail.setError("Must fill in the email");
            editTextUpdateemail.requestFocus();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(textEmail).matches()) {
            Toast.makeText(UpdateProfileActivity.this, "Enter a valid email", Toast.LENGTH_LONG).show();
            editTextUpdateemail.setError("Invalid email");
            editTextUpdateemail.requestFocus();
        } else if (TextUtils.isEmpty(textMajor)) {
            Toast.makeText(UpdateProfileActivity.this, "Fill in the major", Toast.LENGTH_LONG).show();
            editTextUpdatemajor.setError("Must fill in the major");
            editTextUpdatemajor.requestFocus();
        } else if (TextUtils.isEmpty(rgButtonUpdateSelected.getText())) {
            Toast.makeText(UpdateProfileActivity.this, "Select a gender", Toast.LENGTH_LONG).show();
        } else if (TextUtils.isEmpty(textMobile)) {
            Toast.makeText(UpdateProfileActivity.this, "Fill in the mobile number", Toast.LENGTH_LONG).show();
            editTextUpdatemobile.setError("Must fill in the mobile number");
            editTextUpdatemobile.requestFocus();
        } else {
            textGender = rgButtonUpdateSelected.getText().toString();

            // Update the profile
            ReadWriteUserDetails writeUserDetails = new ReadWriteUserDetails(textFullName, textEmail, textPwd, textMajor, textGender, textMobile);
            String userID = firebaseUser.getUid();
            referenceProfile.child(userID).setValue(writeUserDetails).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        // Update the password
                        updatePassword(firebaseUser);

                        UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder().setDisplayName(textFullName).build();
                        firebaseUser.updateProfile(profileUpdates);
                        Toast.makeText(UpdateProfileActivity.this, "Update is done!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(UpdateProfileActivity.this, ProfileActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(UpdateProfileActivity.this, "Failed to update profile", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    private void updatePassword(FirebaseUser firebaseUser) {
        String newPassword = editTextUpdatepwd.getText().toString();
        firebaseUser.updatePassword(newPassword)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(UpdateProfileActivity.this, "Password updated successfully", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(UpdateProfileActivity.this, "Failed to update password", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void showProfile(FirebaseUser firebaseUser) {
        String userIDofRegistered = firebaseUser.getUid();
        referenceProfile.child(userIDofRegistered).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ReadWriteUserDetails readUserDetails = snapshot.getValue(ReadWriteUserDetails.class);
                if (readUserDetails != null) {
                    textFullName = readUserDetails.getTextFullname();
                    textMajor = readUserDetails.getTextmajor();
                    textGender = readUserDetails.getTextGender();
                    textPwd = readUserDetails.getTextpwd();
                    textEmail = readUserDetails.getTextemail();
                    textMobile = readUserDetails.getTextmobile();

                    editTextUpdatename.setText(textFullName);
                    editTextUpdateemail.setText(textEmail);
                    editTextUpdatemajor.setText(textMajor);
                    editTextUpdatemobile.setText(textMobile);

                    if (textGender.equals("Male")) {
                        rgButtonUpdateSelected = findViewById(R.id.radio_male);
                    } else {
                        rgButtonUpdateSelected = findViewById(R.id.radio_female);
                    }
                    rgButtonUpdateSelected.setChecked(true);
                } else {
                    Toast.makeText(UpdateProfileActivity.this, "Failed to load profile", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateProfileActivity.this, "Failed to load profile", Toast.LENGTH_LONG).show();
            }
        });
    }
}
