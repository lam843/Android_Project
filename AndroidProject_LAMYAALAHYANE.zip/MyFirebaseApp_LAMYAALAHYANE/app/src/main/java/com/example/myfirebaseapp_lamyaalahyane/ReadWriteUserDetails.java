package com.example.myfirebaseapp_lamyaalahyane;

public class ReadWriteUserDetails {

    public String textFullname, textemail, textmajor, textGender,textmobile,textpwd;
    public ReadWriteUserDetails() {
        // Default constructor required for Firebase
    }
public ReadWriteUserDetails( String textFullname,  String textemail,String textpwd, String textmajor, String textGender,String textmobile){
    this.textFullname=textFullname;
    this.textemail=textemail;
    this.textGender=textGender;
    this.textmajor=textmajor;
    this.textmobile=textmobile;
    this.textpwd=textpwd;
}

    public String getTextpwd() {
        return textpwd;
    }

    public void setTextpwd(String textpwd) {
        this.textpwd = textpwd;
    }

    public String getTextFullname() {
        return textFullname;
    }

    public void setTextFullname(String textFullname) {
        this.textFullname = textFullname;
    }

    public String getTextemail() {
        return textemail;
    }

    public void setTextemail(String textemail) {
        this.textemail = textemail;
    }

    public String getTextmajor() {
        return textmajor;
    }

    public void setTextmajor(String textmajor) {
        this.textmajor = textmajor;
    }

    public String getTextGender() {
        return textGender;
    }

    public void setTextGender(String textGender) {
        this.textGender = textGender;
    }

    public String getTextmobile() {
        return textmobile;
    }

    public void setTextmobile(String textmobile) {
        this.textmobile = textmobile;
    }
}
