package com.example.myfirebaseapp_lamyaalahyane;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class ProfileActivity extends AppCompatActivity {
   private TextView textviewwelcome,textviewname,textviewemail,textviewmajor,textviewgender,textviewmobile,textviewpwd;
   private String name,email,major,gender,mobile,pwd;
   private ImageView imageView;
   private FirebaseAuth authProfile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        getSupportActionBar().setTitle("Profile");


        textviewwelcome=findViewById(R.id.textView_show_welcome);
        textviewname=findViewById(R.id.textView_show_full_name);
        textviewemail=findViewById(R.id.textView_show_email);
        textviewmajor=findViewById(R.id.textView_show_major);
        textviewmobile=findViewById(R.id.textView_show_mobile);
        textviewgender=findViewById(R.id.textView_show_gender);
        textviewpwd=findViewById(R.id.textView_show_pwd);

        imageView=findViewById(R.id.imageView_profile_dp);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ProfileActivity.this,UploadProfilePicActivity.class);
                startActivity(intent);
            }
        });

        authProfile=FirebaseAuth.getInstance();
        FirebaseUser firebaseUser=authProfile.getCurrentUser();
        if(firebaseUser==null){
            Toast.makeText(ProfileActivity.this, "Somthing went wrong ", Toast.LENGTH_LONG).show();
        }else{
            showUserProfile(firebaseUser);
        }
    }
    private void showUserProfile(FirebaseUser firebaseUser) {
        String userID = firebaseUser.getUid();

        DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference().child("Registered Users").child(userID);

        referenceProfile.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Retrieve user profile data
                    name = snapshot.child("textFullname").getValue(String.class);
                    email = snapshot.child("textemail").getValue(String.class);
                    major = snapshot.child("textmajor").getValue(String.class);
                    gender = snapshot.child("textGender").getValue(String.class);
                    mobile = snapshot.child("textmobile").getValue(String.class);
                    pwd = snapshot.child("textpwd").getValue(String.class);

                    // Set the retrieved data to the corresponding TextViews
                    textviewwelcome.setText("Welcome, " + name + " ;)");
                    textviewname.setText(name);
                    textviewemail.setText(email);
                    textviewmajor.setText(major);
                    textviewmobile.setText(mobile);
                    textviewgender.setText(gender);
                    textviewpwd.setText(pwd);


                    Uri uri = firebaseUser.getPhotoUrl();
                    Picasso.with(ProfileActivity.this).load(uri).into(imageView);

                    // Debug logs
                    Log.d("FirebaseData", "Name: " + name);
                    Log.d("FirebaseData", "Email: " + email);
                    Log.d("FirebaseData", "Major: " + major);
                    Log.d("FirebaseData", "Gender: " + gender);
                    Log.d("FirebaseData", "Mobile: " + mobile);
                    Log.d("FirebaseData", "pwd: " + pwd);

                } else {
                    Toast.makeText(ProfileActivity.this, "User profile not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileActivity.this, "Something went wrong!", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.common_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.menu_refresh) {
            startActivity(getIntent());
            finish();
            overridePendingTransition(0,0);
        }else if (id == R.id.menu_home){
            Intent intent = new Intent (ProfileActivity.this, HomeActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_update_profile){
            Intent intent = new Intent (ProfileActivity.this, UpdateProfileActivity.class);
            startActivity(intent);
    }  else if (id == R.id.menu_logout){
            authProfile.signOut();
            Toast.makeText(ProfileActivity.this, "LogOut... ", Toast.LENGTH_LONG).show();
            Intent intent = new Intent ( ProfileActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent) ;
        finish();
        }else{
            Toast.makeText(ProfileActivity.this, "Somthing is wrong ... ", Toast.LENGTH_LONG).show();


        }
        return super.onOptionsItemSelected(item);
    }
}
