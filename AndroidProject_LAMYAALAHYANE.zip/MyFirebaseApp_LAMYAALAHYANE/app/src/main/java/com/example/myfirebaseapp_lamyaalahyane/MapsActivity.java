package com.example.myfirebaseapp_lamyaalahyane;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;

    private MapView mapView;
    private GoogleMap googleMap;
    private Button btnSetLocation;
    private Button btnStartTracking;
    private Button btnStopTracking;
    private TextView tvActivityType;
    private TextView tvCalories;
    private TextView tvDistance;
    private TextView tvSpeed;
    private TextView tvAvgSpeed;

    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;

    private boolean isTracking = false;
    private List<LatLng> locations;
    private Polyline polyline;
    private float totalDistance = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_maps);

        mapView = findViewById(R.id.mapView);
        btnSetLocation = findViewById(R.id.btn_set_location);
        btnStartTracking = findViewById(R.id.btn_start_tracking);
        btnStopTracking = findViewById(R.id.btn_stop_tracking);
        tvActivityType = findViewById(R.id.tv_activity_type);
        tvCalories = findViewById(R.id.tv_calories);
        tvDistance = findViewById(R.id.tv_distance);
        tvSpeed = findViewById(R.id.tv_speed);
        tvAvgSpeed = findViewById(R.id.tv_avg_speed);

        // Initialize the MapView
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        btnSetLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (googleMap != null) {
                    googleMap.clear();
                    locations.clear();
                    polyline = null;
                    totalDistance = 0f;
                    tvDistance.setText(String.format("%.2f meters", totalDistance));
                    Toast.makeText(MapsActivity.this, "Location markers cleared", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnStartTracking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTracking();
            }
        });

        btnStopTracking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopTracking();
            }
        });

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }

                for (Location location : locationResult.getLocations()) {
                    updateLocationOnMap(location);
                }
            }
        };
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
        this.googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(0, 0), 10f));
        this.googleMap.getUiSettings().setZoomControlsEnabled(true);
        locations = new ArrayList<>();
    }

    private void startTracking() {
        if (isTracking) {
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        } else {
            fusedLocationClient.requestLocationUpdates(createLocationRequest(), locationCallback, null);
            isTracking = true;
        }
    }

    private void stopTracking() {
        if (!isTracking) {
            return;
        }

        fusedLocationClient.removeLocationUpdates(locationCallback);
        isTracking = false;
        calculateFinalMetrics();
    }

    private LocationRequest createLocationRequest() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(500);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        return locationRequest;
    }

    private void updateLocationOnMap(Location location) {
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f));
        googleMap.addMarker(new MarkerOptions().position(latLng));

        if (locations.isEmpty()) {
            locations.add(latLng);
        } else {
            LatLng previousLocation = locations.get(locations.size() - 1);
            float distance = calculateDistance(previousLocation, latLng);
            totalDistance += distance;
            tvDistance.setText(String.format("%.2f meters", totalDistance));
            locations.add(latLng);

            if (polyline != null) {
                polyline.remove();
            }

            PolylineOptions polylineOptions = new PolylineOptions()
                    .addAll(locations)
                    .color(Color.RED)
                    .width(5f);
            polyline = googleMap.addPolyline(polylineOptions);
        }
    }

    private float calculateDistance(LatLng start, LatLng end) {
        float[] results = new float[1];
        Location.distanceBetween(start.latitude, start.longitude, end.latitude, end.longitude, results);
        return results[0];
    }

    private void calculateFinalMetrics() {
        if (locations.size() >= 2) {
            LatLng startLocation = locations.get(0);
            LatLng endLocation = locations.get(locations.size() - 1);
            float distance = calculateDistance(startLocation, endLocation);
            float averageSpeed = distance / totalDistance;
            // Update the UI with final metrics
            tvDistance.setText(String.format("%.2f meters", totalDistance));
            tvAvgSpeed.setText(String.format("%.2f meters/s", averageSpeed));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startTracking();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}
